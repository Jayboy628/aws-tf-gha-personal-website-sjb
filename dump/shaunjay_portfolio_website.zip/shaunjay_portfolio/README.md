# Shaunjay J. Brown — Personal Website

A responsive personal leadership portfolio built with plain HTML, CSS, and JavaScript.

## Run locally

Open `index.html` directly in a browser, or use a local server:

```bash
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.

## Files

- `index.html` — website content and layout
- `styles.css` — responsive visual design
- `script.js` — mobile navigation, scroll effects, and current year
- `assets/shaunjay-brown.jpg` — profile image

## Before publishing

Review all dates, job titles, institution names, and company names for accuracy. Add a downloadable resume or project links when ready.
